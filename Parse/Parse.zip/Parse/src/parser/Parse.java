package parser;

import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Parse {
	 
	public static void main(String[] args){
		ArrayList <String> Name = new ArrayList<>(Arrays.asList("sin10ResultTJ.txt", "sin10TX.txt"));
		for(int j =0; j<Name.size();j++){
		try {
			File file = new File(Name.get(j));
			FileReader fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			StringBuffer stringBuffer = new StringBuffer();
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuffer.append(line);
			}
			fileReader.close();
			
			String delims = "[ ]";
			String[] tokens = stringBuffer.toString().split(delims);
			System.out.println("Contents of file:");
			int temp=0;
			for ( int i = 0; i < tokens.length; i++){
				//System.out.println(tokens[i]);
				temp+=Integer.parseInt(tokens[i]);
			}
		//
			
			System.out.println(Name.get(j)+": Average Time: ");
			System.out.println("Length: "+tokens.length);

			System.out.println(temp/tokens.length);
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
	}

}
